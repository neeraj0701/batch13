﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace OrderInfoApp
{
    public class ResponseTime
    {
        public async Task CalculateResponseTimeAsync(string xmlFilePath)
        {
            var readXmlObj = new ReadXml();

            try
            {
                XDocument document = XDocument.Load(xmlFilePath);
                var startTime = DateTime.Now;

                Task<string> orderIdTask = readXmlObj.ReadPropertyValueAsync(document.Root?.Element("ID"));
                Console.WriteLine($"Order ID: {orderIdTask.Result}");

                Task<string> orderRequestDateTask = readXmlObj.ReadPropertyValueAsync(document.Root?.Element("RequestedShipDate"));
                Console.WriteLine($"Order Request Date: {orderRequestDateTask.Result}");

                Task<string> createdByTask = readXmlObj.ReadPropertyValueAsync(document.Root?.Element("CreatedBy"));
                Console.WriteLine($"Created By: {createdByTask.Result}");

                var loadTasks = document.Root.Elements("Items").Elements("Item").Select(item => readXmlObj.ReadPropertyValueAsync(item.Element("LOADFACTOR")));
                double totalLoad = (await Task.WhenAll(loadTasks)).Sum(item => double.Parse(item ?? "0"));
                Console.WriteLine($"Load of the Order: {totalLoad}");

                var quantityTasks = document.Root.Elements("Items").Elements("Item").Select(item => readXmlObj.ReadPropertyValueAsync(item.Element("Order_Quantity")));
                int totalQuantity = (await Task.WhenAll(quantityTasks)).Sum(item => int.Parse(item ?? "0"));
                Console.WriteLine($"Quantities of the Order: {totalQuantity}");

                var priceTasks = document.Root.Elements("Items").Elements("Item").Select(item => readXmlObj.ReadPropertyValueAsync(item.Element("USPrice")));
                decimal totalPrice = (await Task.WhenAll(priceTasks)).Sum(item => decimal.Parse(item ?? "0"));
                Console.WriteLine($"Price: {totalPrice}");

                Task<string> customerNameTask = readXmlObj.ReadPropertyValueAsync(document.Root?.Element("CustomerInfo")?.Element("Billing")?.Element("Name"));
                Console.WriteLine($"Customer Name: {customerNameTask.Result}");

                Task<string> customerAddressTask = readXmlObj.ReadPropertyValueAsync(document.Root?.Element("CustomerInfo")?.Element("Billing")?.Element("Address1"));
                Console.WriteLine($"Customer Address: {customerAddressTask.Result}");

                Task<string> customerPhoneTask = readXmlObj.ReadPropertyValueAsync(document.Root?.Element("CustomerInfo")?.Element("Billing")?.Element("Phone"));
                Console.WriteLine($"Customer Phone: {customerPhoneTask.Result}");

                Task<string> customerEmailTask = readXmlObj.ReadPropertyValueAsync(document.Root?.Element("CustomerInfo")?.Element("Billing")?.Element("DeliveryReceiptEmail"));
                Console.WriteLine($"Customer Email: {customerEmailTask.Result}");

                await Task.WhenAll(orderIdTask, orderRequestDateTask, createdByTask, customerNameTask, customerAddressTask, customerPhoneTask, customerEmailTask);

                var endTime = DateTime.Now;

                Console.WriteLine($"Total response time: {endTime - startTime} ms");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing XML: {ex.Message}");
            }
        }
    }
}
