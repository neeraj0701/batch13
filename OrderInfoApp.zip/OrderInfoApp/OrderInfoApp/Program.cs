﻿using System;
using System.IO;
using System.Threading.Tasks;

namespace OrderInfoApp
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            string xmlFilePath = "C:\\Users\\Neeraj Potlapalli\\source\\repos\\OrderInfoApp\\OrderInfoApp\\OrderDetails.xml"; // Replace with the actual path to your XML file

            if (!File.Exists(xmlFilePath))
            {
                Console.WriteLine("XML file not found.");
                return;
            }

            ResponseTime responseTimeObj = new ResponseTime();
            await responseTimeObj.CalculateResponseTimeAsync(xmlFilePath);
        }
    }
}
