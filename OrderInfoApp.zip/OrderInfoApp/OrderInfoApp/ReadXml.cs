﻿using System;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace OrderInfoApp
{
    public class ReadXml
    {
        public async Task<string> ReadPropertyValueAsync(XElement element)
        {
            if (element != null)
            {
                var startTime = DateTime.Now;
                string value = element.Value.Trim();
                var endTime = DateTime.Now;
                Console.WriteLine($"Response time for '{element.Name.LocalName}': {endTime - startTime} ms");

                return await Task.FromResult(value);
            }

            return null;
        }
    }
}

